<?php
header("Location: /fa/");
exit();
